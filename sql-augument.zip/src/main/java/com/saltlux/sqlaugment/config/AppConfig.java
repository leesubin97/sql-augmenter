package com.saltlux.sqlaugment.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.spotify.annoy.IndexType;

public class AppConfig {
	
	private static Properties properties;
	 
	static {
		properties = new Properties();
		try (InputStream input = AppConfig.class
				.getResourceAsStream("/config/SQLAugmenter_config.ini")) {
			properties.load(input);
		} catch (IOException e) {
			throw new RuntimeException("Unable to read the configuration file", e);
		}
	}

	public static String getVectoriseUrl() {
		return getProperty("vectorise.api.url");
	}

	public static String getDataSetJson() {
		return getProperty("similar.query.dataset.path");
	}

	public static int getVectorDimension() {
		System.out.println(Integer.parseInt(getProperty("vectorise.dimension")));
		return Integer.parseInt(getProperty("vectorise.dimension"));
	}

	public static String getAnnoyTypePath(IndexType indexType) {
		String propertyName = "annoy." + indexType.toString().toUpperCase() + ".filePath";
		return getProperty(propertyName);
	}

	private static String getProperty(String key) {
		return properties.getProperty(key);
	}
}
