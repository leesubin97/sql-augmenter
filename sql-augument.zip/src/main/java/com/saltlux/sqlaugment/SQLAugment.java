package com.saltlux.sqlaugment;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.saltlux.sqlaugment.config.AppConfig;
import com.spotify.annoy.ANNIndex;
import com.spotify.annoy.IndexType;

public class SQLAugment {

	private static Map<IndexType, ANNIndex> indexMap = new HashMap<IndexType, ANNIndex>();

	/**
	 * 클래스 호출시 인덱스 생성
	 * 
	 * @throws Exception
	 */
	public SQLAugment() throws Exception {
		for (IndexType indexType : IndexType.values()) {
			ANNIndex vectorIndex = makeAnnIndex(indexType);
			indexMap.put(indexType, vectorIndex);
		}
	}

	private ANNIndex makeAnnIndex(IndexType indexType) throws Exception {
		ANNIndex vectorIndex = null;
		try {
			vectorIndex = new ANNIndex(AppConfig.getVectorDimension(), AppConfig.getAnnoyTypePath(indexType),
					indexType);
		} catch (Exception e) {
			throw new Exception("Failed to create an index", e);
		} finally {
			if (vectorIndex != null) {
				closeAnnIndex(vectorIndex);
			}
		}
		return vectorIndex;
	}

	/**
	 * 자연어 질의 입력시 유사 질문 추출
	 * 
	 * @param 자연어, 검색 갯수, 인덱스 타입
	 * @return 유사 질문 출력
	 * @throws Exception
	 */
	public List<String> getSimilarQuestionList(String nl, int searchCnt, IndexType indexType) throws Exception {
		return getSimilarDataByDataSetKey(nl, searchCnt, indexType, "question");
	}

	/**
	 * 자연어 질의 입력시 유사 쿼리 추출
	 * 
	 * @param 자연어, 검색 갯수, 인덱스 타입
	 * @return 유사 쿼리 출력
	 * @throws Exception
	 */
	public List<String> getSimilarQueryList(String nl, int searchCnt, IndexType indexType) throws Exception {
		return getSimilarDataByDataSetKey(nl, searchCnt, indexType, "query");
	}

	/**
	 * 자연어 질의 입력시 유사 템플릿 추출
	 * 
	 * @param 자연어, 검색 갯수, 인덱스 타입
	 * @return 유사 템플릿 출력
	 * @throws Exception
	 */
	public List<String> getSimilarQueryTempleteList(String nl, int searchCnt, IndexType indexType) throws Exception {
		return getSimilarDataByDataSetKey(nl, searchCnt, indexType, "query_temp");
	}

	/**
	 * 자연어 질의 입력시 유사 쿼리 추출
	 * 
	 * @param 자연어, 검색 갯수, 인덱스 타입, 리턴 결과 인덱스
	 * @return 유사 정보 출력
	 * @throws Exception
	 */
	private List<String> getSimilarDataByDataSetKey(String nl, int searchCnt, IndexType indexType, String dataSetKey)
			throws Exception {
		List<List<Map<String, Object>>> annoyMappingData = readAndParseJsonFile(AppConfig.getDataSetJson());
		List<String> resultList = new ArrayList<>();
		ANNIndex vectorIndex = null;

		try {
			// Step 1. vector API 호출
			String apiReturn = callVectorizationApi(nl);
			JSONParser parser = new JSONParser();
			JSONObject apiResult = (JSONObject) parser.parse(apiReturn);
			List<Double> vectors = (List<Double>) apiResult.get("vector");
			// Step 2. 벡터 정보 형식 변환
			float[] param = toFloatArray(vectors);
			// Step 3. 인덱스 타입에 따른 인덱스 분류
			vectorIndex = indexMap.get(indexType);
			// Step 4. 유사 정보 검색
			List<Integer> searchIdxList = vectorIndex.getNearest(param, searchCnt);
			// Step 5. 유사 정보 인덱스로 데이터 추출
			for (Integer idx : searchIdxList) {
				List<Map<String, Object>> resultRow = annoyMappingData.get(idx);
				for (Map<String, Object> item : resultRow) {
					Object questionObj = item.get(dataSetKey);
					if (questionObj != null) {
						String question = questionObj.toString();
						resultList.add(question);
					}
				}
			}

		} catch (Exception e) {
			throw new Exception("Failed to retrieve similar information", e);
		}
		return resultList;
	}

	/**
	 * 자연어 질의 입력시 유사 질문,쿼리,템플릿 추출
	 * 
	 * @param 자연어, 검색 갯수, 인덱스 타입, 리턴 결과 인덱스
	 * @return 유사 정보 전체 출력 (Key : question, query, query_temp, idx)
	 * @throws Exception
	 */
	public List<Map<String, Object>> getSimilarDatasetList(String nl, int searchCnt, IndexType indexType)
			throws Exception {
		List<List<Map<String, Object>>> annoyMappingData = readAndParseJsonFile(AppConfig.getDataSetJson());
		List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
		ANNIndex vectorIndex = null;

		try {
			// Step 1. vector API 호출
			String apiReturn = callVectorizationApi(nl);
			JSONParser parser = new JSONParser();
			JSONObject apiResult = (JSONObject) parser.parse(apiReturn);
			List<Double> vectors = (List<Double>) apiResult.get("vector");
			// Step 2. 벡터 정보 형식 변환
			float[] param = toFloatArray(vectors);
			// Step 3. 인덱스 타입에 따른 인덱스 분류
			vectorIndex = indexMap.get(indexType);
			// Step 4. 유사 정보 검색
			List<Integer> searchIdxList = vectorIndex.getNearest(param, searchCnt);
			// Step 5. 유사 정보 인덱스로 데이터 추출
			for (Integer idx : searchIdxList) {
				List<Map<String, Object>> resultRow = annoyMappingData.get(idx);
				for (Map<String, Object> item : resultRow) {
					resultList.add(item);
				}
			}
		} catch (Exception e) {
			throw new Exception("Failed to retrieve similar dataSetList", e);
		}
		return resultList;
	}

	/**
	 * 데이터셋 파일 경로를 읽어 형식 변환
	 * 
	 * @param 데이터셋 파일 경로
	 * @return 데이터셋 정보
	 * @throws Exception
	 */
	private List<List<Map<String, Object>>> readAndParseJsonFile(String filePath) throws Exception {
		try {
			File jsonFile = new File(filePath);
			ObjectMapper objectMapper = new ObjectMapper();
			Map<String, Object> jsonMap = objectMapper.readValue(jsonFile, Map.class);
			List<Map<String, Object>> dataList = (List<Map<String, Object>>) jsonMap.get("data");
			List<List<Map<String, Object>>> result = new ArrayList<>();
			for (Map<String, Object> dataItem : dataList) {
				List<Map<String, Object>> item = new ArrayList<>();
				Map<String, Object> itemMap = new HashMap<>();
				itemMap.put("idx", dataItem.get("idx"));
				itemMap.put("question", dataItem.get("question"));
				itemMap.put("query", dataItem.get("query"));
				itemMap.put("query_temp", dataItem.get("query_temp"));
				item.add(itemMap);
				result.add(item);
			}
			return result;
		} catch (Exception e) {
			throw new Exception("Failed to retrieve the dataset file", e);
		}
	}

	/**
	 * Api 호출하여 정보 리턴
	 * 
	 * @param apiUrl, encode, parameter
	 * @return 응답 결과
	 * @throws Exception
	 */
	private String callVectorizationApi(String nl) throws Exception {
		JSONObject reqParam = new JSONObject();
		reqParam.put("vector", nl);

		String vectoriseUrl = AppConfig.getVectoriseUrl();
		String result = null;

		try {
			URL url = new URL(vectoriseUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			try {
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "application/json");
				conn.setRequestProperty("Accept", "application/json");

				try (OutputStream os = conn.getOutputStream()) {
					byte[] input = reqParam.toJSONString().getBytes("UTF-8");
					os.write(input, 0, input.length);
				}

				try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
					StringBuilder response = new StringBuilder();
					String responseLine;
					while ((responseLine = br.readLine()) != null) {
						response.append(responseLine.trim());
					}
					result = response.toString();
				}
			} finally {
				conn.disconnect();
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed to make a vector API call", e);
		}

		return result;
	}

	/**
	 * index close
	 * 
	 * @throws Exception
	 */
	private void closeAnnIndex(ANNIndex vectorIndex) throws Exception {
		try {
			vectorIndex.close();
		} catch (IOException e) {
			throw new Exception("Vector information was not properly closed", e);
		}
	}

	/**
	 * float array
	 */
	private float[] toFloatArray(List<Double> list) {
		if (list == null || list.isEmpty()) {
			return new float[0];
		}

		int size = list.size();
		float[] result = new float[size];
		for (int i = 0; i < size; i++) {
			result[i] = list.get(i).floatValue();
		}

		return result;
	}
}
