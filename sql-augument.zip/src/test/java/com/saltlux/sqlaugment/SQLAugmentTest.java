package com.saltlux.sqlaugment;

import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.spotify.annoy.IndexType;

public class SQLAugmentTest {
	
	@Test
	public void augmentTest() throws Exception {
		SQLAugment sqlAugment = new SQLAugment();
		
		// 유사 질의 출력 테스트
		List<String> similarQuestionList = sqlAugment.getSimilarQuestionList("상품 서비스 이름이 '기본 케이블 TV'인 상품 서비스 명과 설명, 가격을 보여줄래요?", 3, IndexType.DOT);
		
		// 유사 쿼리 출력 테스트
		//List<String> similarQueryList = sqlAugment.getSimilarQueryList("대리점 별로 상품 서비스를 알아야합니다", 10, IndexType.DOT);

		// DOT 각 장비 유형별로 장애 평균 해결 시간, 장비 유형이 필요해요.
		for (String data : similarQuestionList) {
			System.out.println(data + " ");
			System.out.println(); 
		}
		
		// 데이터셋 전체 출력 테스트
		
		List<Map<String,Object>> dataSetList = sqlAugment.getSimilarDatasetList("대리점 별로 상품 서비스를 알아야합니다", 5, IndexType.ANGULAR);
		for (Map<String, Object> entrySet : dataSetList) {
		    for (Map.Entry<String, Object> entry : entrySet.entrySet()) {
		        String key = entry.getKey();
		        Object value = entry.getValue();
		        System.out.println("Key: " + key + ", Value: " + value);
		    }
		    System.out.println("");
		}
		
		
	}
	
	public static void main (String[] args) {
		try {
			SQLAugment sqlAugment = new SQLAugment();
			
			// 유사 질의 출력 테스트
			List<String> similarQuestionList = sqlAugment.getSimilarQuestionList("상품명별로 평균 가격을 보고 싶어요.", 3, IndexType.DOT);
			
			// 유사 쿼리 출력 테스트
			//List<String> similarQueryList = sqlAugment.getSimilarQueryList("대리점 별로 상품 서비스를 알아야합니다", 10, IndexType.DOT);
			
			// DOT 각 장비 유형별로 장애 평균 해결 시간, 장비 유형이 필요해요.
			for (String data : similarQuestionList) {
				System.out.println(data + " ");
				System.out.println(); 
			}
			
			// 데이터셋 전체 출력 테스트
			
			List<Map<String,Object>> dataSetList = sqlAugment.getSimilarDatasetList("대리점 별로 상품 서비스를 알아야합니다", 5, IndexType.ANGULAR);
			for (Map<String, Object> entrySet : dataSetList) {
				for (Map.Entry<String, Object> entry : entrySet.entrySet()) {
					String key = entry.getKey();
					Object value = entry.getValue();
					System.out.println("Key: " + key + ", Value: " + value);
				}
				System.out.println("");
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
